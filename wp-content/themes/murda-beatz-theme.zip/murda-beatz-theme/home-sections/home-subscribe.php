<section class="bk-subscribe padding-bottom-lg padding-top-lg">
	<div class="container">
		<div class="row">
			<div class="col-8 offset-lg-2 padding-top-lg padding-bottom-lg">
				<h2 class="title-white-bk-transparent">
					Subscribe
				</h2>
			</div>
			<div class="col-8 offset-lg-2 padding-top-lg padding-bottom-lg">
				<?php echo do_shortcode( '[contact-form-7 id="49" title="Subscribe"]' ); ?>
			</div>
		</div>
	</div>
</section>