	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-12">

					<p class="font-yellow uppercase margin-bottom-sm margin-top-sm">
						<span>© Interscope Records</span>
						<span>Privacy Policy</span>
						<span>Terms & Conditions</span>
						<span>Cookie Choices</span>
						<span>Do Not Sell My Personal Information</span></p>
				</div>
			</div>
		</div>
	</footer>
<?php wp_footer(); ?>
</body>
</html>